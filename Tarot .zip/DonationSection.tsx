import { useState } from 'react';
import { motion } from 'framer-motion';

interface DonationProps {
  qrCode: string;
}

export default function DonationSection({ qrCode }: DonationProps) {
  const [amount, setAmount] = useState('100');
  const [purpose, setPurpose] = useState('charity');
  const [custom, setCustom] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your donation! Your support creates change.');
  };

  return (
    <section id="donate" className="py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl mb-6">Make a Donation</h2>
        <form onSubmit={handleSubmit} className="bg-white bg-opacity-90 p-8 rounded-lg shadow-lg">
          <div className="mb-4">
            <label className="block mb-2">Amount:</label>
            <select value={amount} onChange={(e) => { setAmount(e.target.value); setCustom(e.target.value === 'custom'); }} className="w-full p-2 border rounded">
              <option value="100">₹100</option>
              <option value="300">₹300</option>
              <option value="500">₹500</option>
              <option value="custom">Custom</option>
            </select>
            {custom && <input type="number" placeholder="Enter amount" className="w-full p-2 border rounded mt-2" />}
          </div>
          <div className="mb-4">
            <label className="block mb-2">Purpose:</label>
            <select value={purpose} onChange={(e) => setPurpose(e.target.value)} className="w-full p-2 border rounded">
              <option value="tarot">Tarot Support</option>
              <option value="charity">Charity Only</option>
              <option value="combined">Tarot + Charity</option>
            </select>
          </div>
          <button type="submit" className="btn">Donate Now</button>
        </form>
        <div className="mt-8">
          <p>UPI ID: goravshr18@okicici</p>
          {qrCode && <img src={qrCode} alt="UPI QR Code" className="mx-auto mt-4 w-32 h-32" />}
        </div>
      </div>
    </section>
  );
}