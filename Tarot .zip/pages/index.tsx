import { useState, useEffect } from 'react';
import Head from 'next/head';
import { motion } from 'framer-motion';
import QRCode from 'qrcode';
import Hero from '../components/Hero';
import TarotSection from '../components/TarotSection';
import CharitySection from '../components/CharitySection';
import DonationSection from '../components/DonationSection';
import ContactSection from '../components/ContactSection';
import AboutSection from '../components/AboutSection';
import LegalSection from '../components/LegalSection';

export default function Home() {
  const [qrCode, setQrCode] = useState('');

  useEffect(() => {
    // Auto-generate UPI QR
    QRCode.toDataURL('upi://pay?pa=goravshr18@okicici&pn=ClarityTalkss&am=100&cu=INR', (err, url) => {
      if (!err) setQrCode(url);
    });
  }, []);

  return (
    <>
      <Head>
        <title>ClarityTalkss - Find Clarity Within. Create Change Beyond.</title>
        <meta name="description" content="Tarot readings for emotional clarity and guidance, supporting charity for social causes." />
        <meta name="keywords" content="tarot reading, spiritual guidance, charity, donations, clarity, healing" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <nav className="fixed top-0 w-full bg-secondary bg-opacity-90 backdrop-blur-md z-50 p-4">
        <ul className="flex justify-center space-x-6 text-primary">
          <li><a href="#home" className="hover:text-accent">Home</a></li>
          <li><a href="#tarot" className="hover:text-accent">Tarot</a></li>
          <li><a href="#charity" className="hover:text-accent">Charity</a></li>
          <li><a href="#donate" className="hover:text-accent">Donate</a></li>
          <li><a href="#about" className="hover:text-accent">About</a></li>
          <li><a href="#contact" className="hover:text-accent">Contact</a></li>
        </ul>
      </nav>
      <Hero />
      <TarotSection />
      <CharitySection />
      <DonationSection qrCode={qrCode} />
      <ContactSection />
      <AboutSection />
      <LegalSection />
      <footer className="bg-secondary text-white text-center p-4">
        &copy; 2023 ClarityTalkss. All rights reserved. Secure & Accessible.
      </footer>
    </>
  );
}