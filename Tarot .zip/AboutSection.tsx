export default function AboutSection() {
  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl mb-6">About ClarityTalkss</h2>
        <p>ClarityTalkss is a platform dedicated to providing tarot readings that foster spiritual clarity and personal growth. Our vision combines honest, ethical guidance with a commitment to social responsibility, ensuring every interaction is respectful and genuine.</p>
      </div>
    </section>
  );
}