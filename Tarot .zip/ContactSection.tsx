export default function ContactSection() {
  return (
    <section id="contact" className="py-20 px-4 bg-white bg-opacity-10">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl mb-6">Contact Us</h2>
        <p className="mb-4">We reply to DMs with care and clarity. Feel free to reach out anytime.</p>
        <a href="https://www.instagram.com/clarity.talkss?igsh=MTg3a2ZkeXdqZjh1Mw==" target="_blank" rel="noopener noreferrer" className="btn">Follow & DM Us on Instagram</a>
      </div>
    </section>
  );
}