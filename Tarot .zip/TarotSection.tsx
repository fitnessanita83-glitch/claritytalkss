import { motion } from 'framer-motion';

export default function TarotSection() {
  const readings = [
    { title: 'Love & Relationships', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' }, // AI-generated tarot card
    { title: 'Career & Finance', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' },
    { title: 'Personal Growth', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' },
    { title: 'Yes / No Guidance', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' },
  ];

  return (
    <section id="tarot" className="py-20 px-4">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-3xl mb-6">Tarot Readings for Insight & Clarity</h2>
        <p className="mb-8">Tarot provides profound insight, clarity, and perspective into life's challenges, offering ethical and honest guidance rooted in spirituality. Our readings empower your journey with respect and integrity.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {readings.map((reading, i) => (
            <motion.div key={i} className="bg-white bg-opacity-90 p-6 rounded-lg shadow-lg" whileHover={{ scale: 1.05 }}>
              <img src={reading.img} alt={reading.title} className="w-full h-40 object-cover rounded mb-4" />
              <h3 className="text-xl mb-2">{reading.title}</h3>
              <a href="#contact" className="btn">Book Now</a>
            </motion.div>
          ))}
        </div>
        <p className="mt-8 italic">Tarot readings are for guidance purposes only and are not a substitute for medical, legal, or financial advice.</p>
      </div>
    </section>
  );
}