module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#4C1D95", // Deep purple
        secondary: "#1E293B", // Midnight blue
        accent: "#F59E0B", // Soft gold
      },
    },
  },
  plugins: [],
};