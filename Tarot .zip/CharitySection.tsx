import { motion } from 'framer-motion';

export default function CharitySection() {
  const impacts = [
    { title: 'Emotional Wellbeing', desc: 'Supporting mental health resources.', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' }, // AI-generated charity visual
    { title: 'Underprivileged Help', desc: 'Aid for education and basic needs.', img: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/...' },
  ];

  return (
    <section id="charity" className="py-20 px-4 bg-white bg-opacity-10">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="text-3xl mb-6">Charity & Impact</h2>
        <p className="mb-8">Our mission is to blend spiritual clarity with social responsibility, supporting emotional wellbeing, helping underprivileged communities, and providing education and basic needs assistance. All donations are used responsibly to create meaningful impact.</p>
        <div className="grid md:grid-cols-2 gap-6">
          {impacts.map((impact, i) => (
            <motion.div key={i} className="bg-white p-6 rounded-lg shadow-lg" whileHover={{ y: -10 }}>
              <img src={impact.img} alt={impact.title} className="w-full h-32 object-cover rounded mb-4" />
              <h3 className="text-xl mb-2">{impact.title}</h3>
              <p>{impact.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}