export default function LegalSection() {
  return (
    <section className="py-20 px-4 bg-secondary text-white">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl mb-6 text-accent">Legal & Trust</h2>
        <details className="mb-4">
          <summary className="cursor-pointer">Privacy Policy</summary>
          <p>We collect minimal data for readings and donations, ensuring privacy and no sharing without consent.</p>
        </details>
        <details className="mb-4">
          <summary className="cursor-pointer">Terms & Conditions</summary>
          <p>Services are for guidance only;